export default {async fetch(req,env){
const headers={'Access-Control-Allow-Origin':'https://tezgah.invalid','Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'};
if(req.method==='OPTIONS')return new Response(null,{headers});
if(!env.ACCESS_TOKEN||req.headers.get('Authorization')!=='Bearer '+env.ACCESS_TOKEN)return new Response(null,{status:401,headers});
const d=await req.json();
const prompt='Türkçe mutfak koçusun. İlk turda tarifi webde ara, ölçüleri ve ilk adımı söyle. Sonraki turlarda sesli soruları yanıtla, yalnızca açıkça görülen hataları bildir. Belirsizse sor. Görüntüden kesin gramaj veya güvenli iç sıcaklık çıkarma. Yeni bilgi yoksa sadece BEKLE yaz. Tarif: '+d.dish+' Önceki yönlendirmeler: '+JSON.stringify(d.history);
const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(env.MODEL)+':generateContent',{method:'POST',headers:{'x-goog-api-key':env.GEMINI_API_KEY,'content-type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt},{inlineData:{mimeType:'image/jpeg',data:d.image}},{inlineData:{mimeType:d.mime,data:d.audio}}]}],tools:d.history.length?[]:[{google_search:{}}]})});
if(!r.ok)return new Response(null,{status:r.status,headers});
const c=(await r.json()).candidates?.[0];return Response.json({text:c?.content?.parts?.map(p=>p.text||'').join('')||'BEKLE',sources:(c?.groundingMetadata?.groundingChunks||[]).map(x=>x.web?.title).filter(Boolean)},{headers})}}
