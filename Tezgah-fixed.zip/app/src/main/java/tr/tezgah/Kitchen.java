package tr.tezgah;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.pm.PackageManager;
public class Kitchen extends Activity {
 WebView view;
 public void onCreate(Bundle b){super.onCreate(b);view=new WebView(this);setContentView(view);view.getSettings().setJavaScriptEnabled(true);
 view.setWebViewClient(new WebViewClient(){
 public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return true;}
 public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){if(r.getUrl().toString().equals("https://tezgah.invalid/"))try{return new WebResourceResponse("text/html","UTF-8",getAssets().open("kitchen.html"));}catch(Exception ignored){}return null;}
 });view.setWebChromeClient(new WebChromeClient(){public void onPermissionRequest(PermissionRequest r){if(r.getOrigin().getHost().equals("tezgah.invalid") && checkSelfPermission(android.Manifest.permission.CAMERA)==0 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)==0)r.grant(r.getResources());else r.deny();}});
 requestPermissions(new String[]{android.Manifest.permission.CAMERA,android.Manifest.permission.RECORD_AUDIO},1);view.loadUrl("https://tezgah.invalid/");}
 protected void onPause(){super.onPause();view.evaluateJavascript("stopSession()",null);}
}
